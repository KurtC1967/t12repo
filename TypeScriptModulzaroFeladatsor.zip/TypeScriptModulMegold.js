function MegtettUt(sebesseg, ido) {
    return sebesseg * ido;
}
function HosegriadoSzint(nap1, nap2, nap3) {
    //let atlag: number = (nap1 + nap2 + nap3) / 3;
    if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27) {
        return 3;
    }
    else if (nap1 >= 25 && nap1 < 27 && nap2 >= 25 && nap2 < 27 && nap3 >= 25 && nap3 < 27) {
        return 2;
    }
    else if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) {
        return 1;
    }
    else {
        return 0;
    }
}
/* Sikerült eltöltenem kb 25 percet a 3. feladattal. Működött js.do-ban mégis hibára futott a unit teszt, ugyanis ügyesen elírtam a függyvény nevét xD */
function OszthatoSzamok(oszto, vizsgaltTomb) {
    var maradekNelkulOszthato = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % oszto === 0) {
            maradekNelkulOszthato++;
        }
    }
    return maradekNelkulOszthato;
}
function Erettsegi(pontok) {
    var eredmeny = 0;
    for (var i = 0; i < pontok.length; i++) {
        eredmeny += pontok[i];
    }
    if (eredmeny >= 120) {
        return [eredmeny, 5];
    }
    else if (eredmeny >= 80) {
        return [eredmeny, 4];
    }
    else if (eredmeny >= 60) {
        return [eredmeny, 3];
    }
    else if (eredmeny >= 40) {
        return [eredmeny, 2];
    }
    else {
        return [eredmeny, 1];
    }
}
function LeetKod(vizsgaltSzoveg) {
    var modoltSzoveg = vizsgaltSzoveg;
    modoltSzoveg = modoltSzoveg.replace(/I/g, '1');
    modoltSzoveg = modoltSzoveg.replace(/o/g, '0');
    modoltSzoveg = modoltSzoveg.replace(/O/g, '0');
    modoltSzoveg = modoltSzoveg.replace(/a/g, '4');
    modoltSzoveg = modoltSzoveg.replace(/i/g, '1');
    modoltSzoveg = modoltSzoveg.replace(/A/g, '4');
    modoltSzoveg = modoltSzoveg.replace(/e/g, '3');
    modoltSzoveg = modoltSzoveg.replace(/E/g, '3');
    return modoltSzoveg;
}
function ObjektumFeltolto(snookerInfo) {
}
function LegtobbNyeremeny(vizsgaltObjektum) {
}
